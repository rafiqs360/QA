const { test } = require('@playwright/test');

const LoginPage = require('../pages/LoginPage');
const InventoryPage = require('../pages/InventoryPage');
const CartPage = require('../pages/CartPage');
const CheckoutPage = require('../pages/CheckoutPage');

test('Complete Order Flow', async ({ page }) => {

    const loginPage = new LoginPage(page);
    const inventoryPage = new InventoryPage(page);
    const cartPage = new CartPage(page);
    const checkoutPage = new CheckoutPage(page);

  await loginPage.openWebsite();

  await loginPage.login(
      "standard_user",
      "secret_sauce"
  );

  await inventoryPage.verifyLogin();

  await inventoryPage.addProductByPrice("$15.99");

  await inventoryPage.openCart();

  await cartPage.verifyCart("$15.99");

  await cartPage.checkout();

  await checkoutPage.completeCheckout(
      "Test",
      "User",
      "1234"
  );

  await checkoutPage.verifySuccess();

});