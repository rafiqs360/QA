const { expect } = require('@playwright/test');

class InventoryPage {

    constructor(page) {

        this.page = page;

        this.inventoryItems = page.locator(".inventory_item");
        this.cartButton = page.locator(".shopping_cart_link");

    }

    async verifyLogin() {

        await expect(this.page).toHaveURL(/inventory/);

    }

    async addProductByPrice(priceValue) {

        const count = await this.inventoryItems.count();

        for (let i = 0; i < count; i++) {

            const item = this.inventoryItems.nth(i);

            const price = await item.locator(".inventory_item_price").textContent();

            if (price.trim() === priceValue) {

                const button = item.locator("button");

                await button.click();

                await expect(button).toHaveText("Remove");

                break;

            }

        }

    }

    async openCart() {

        await this.cartButton.click();

    }

}

module.exports = InventoryPage;