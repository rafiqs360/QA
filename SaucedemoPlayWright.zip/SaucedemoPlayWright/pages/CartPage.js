const { expect } = require('@playwright/test');

class CartPage {

    constructor(page) {

        this.page = page;

        this.cartItems = page.locator(".cart_item");

        this.price = page.locator(".inventory_item_price");

        this.checkoutButton = page.locator("#checkout");

    }

    async verifyCart(priceValue) {

        await expect(this.cartItems).toHaveCount(1);

        await expect(this.price).toHaveText(priceValue);

    }

    async checkout() {

        await this.checkoutButton.click();

    }

}

module.exports = CartPage;